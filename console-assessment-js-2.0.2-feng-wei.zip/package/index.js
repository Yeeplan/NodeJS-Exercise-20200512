/**
 * Example problem with existing solution and passing test.
 * See problem 0 in the spec file for the assertion
 * @returns {string}
 */
exports.example = () => 'hello world';

exports.stripPrivateProperties = (keyArr, arrObj) => {
	return arrObj.map(item => {
		keyArr.forEach(key => {
			delete item[key];
		});
		return item;
	});
};
exports.excludeByProperty = (key, arrObj) => {
	return arrObj.filter(item => {
		return Object.keys(item).indexOf(key) < 0;
	});
};
exports.sumDeep = (arr) => {
	return arr.map(obj => {
		obj.objects = obj.objects.reduce((prev, current) => {
			return typeof(prev) === 'object' ? prev.val  + current.val : prev + current.val;
		});
		return obj;
	});
};
exports.applyStatusColor = (colorMap, items) => {
	const colors = Object.keys(colorMap);
	return items.map(item => {
		const { status } = item;
		const color = colors.find(item => colorMap[item].indexOf(status) > -1);
		return { status, color };
	}).filter(item => item && item.color);
};
exports.createGreeting = (great, tpl) => {
	return (name) => {
		return great(tpl, name);
	};
};
exports.setDefaults = (def) => {
	return (item) => {
		return {
			...def,
			...item
		};
	};
};
exports.fetchUserByNameAndUsersCompany = (name, services) => {
	const promises = [];
	promises.push(services.fetchUsers());
	promises.push(services.fetchStatus());
	return Promise.all(promises).then(([users, status]) => {
		const user = users.find(user => user.name === name );
		if(!user) return null;
		return services.fetchCompanyById(user.companyId).then(company => {
			return Promise.resolve({
				company,
				status,
				user
			});
		});
	});
};
